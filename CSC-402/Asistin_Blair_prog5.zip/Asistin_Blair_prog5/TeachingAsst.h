//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#pragma once
#include <iostream>
#include <string>
#include "Person.h"
#include "Student.h"
#include "Faculty.h"

class TeachingAsst : public Student, public Faculty  {

protected:
    int courseLoad;

public:

    //Default Constructor
    TeachingAsst();

    //Constructor for storing Person Constructor, Student Constructor, and Faculty Constructor
    TeachingAsst(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age, string classRank, float gpa, string major, string minor, int credits, string department, string office, string email, string officePhone, int courseLoad);

    //Prints Teaching Assistant's Personal Info, Student Info, and Faculty Info
    void printPersonalInfo();


};




