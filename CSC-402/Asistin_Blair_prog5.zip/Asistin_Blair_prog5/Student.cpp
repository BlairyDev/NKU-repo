//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#include "Student.h"

//Default Constructor
Student::Student() {

    classRank = "None";
    gpa = 0.0;
    major = "NONE";
    minor = "NONE";
    credits = 0;

}


//Constructor for storing Person Constructor and data members of Student
Student::Student(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age, string classRank, float gpa, string major, string minor, int credits) :
Person(firstname, lastname, streetaddress, city, state, zipcode, phone, age), classRank(classRank), gpa(gpa), major(major), minor(minor), credits(credits) {};


//Constructor to be used for TeachingAsst class
Student::Student(string classRank, float gpa, string major, string minor, int credits) {

    this->classRank = classRank;
    this->gpa = gpa;
    this->major = major;
    this->minor = minor;
    this->credits = credits;

}

//Prints Student's Personal Info and Student Info
void Student::printPersonalInfo() {
    cout << "S-T-U-D-E-N-T" << endl;
    cout << "-------------" << endl;

    Person::printPersonalInfo(); //Prints Personal Info in Person Class

    printStudentInfo();// Prints Student Info

};

//Prints Student Info
void Student::printStudentInfo() {

    cout << "STUDENT INFO" << endl;
    cout << classRank << "  " << "GPA: " << gpa << endl;
    cout << major << "  " << minor << endl;
    cout << "Total Credits : " << credits << endl;

};






