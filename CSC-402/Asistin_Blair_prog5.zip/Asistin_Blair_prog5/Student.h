//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#pragma once
#include <iostream>
#include <string>
#include "Person.h"
using namespace std;

class Student : virtual public Person{
protected:
    string classRank;
    float gpa;
    string major;
    string minor;
    int credits;

public:

    //Default Constructor
    Student();

    //Constructor for storing Person Constructor and data members of Student
    Student(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age, string classRank, float gpa, string major, string minor, int credits);

    //Constructor to be used for TeachingAsst class
    Student(string classRank, float gpa, string major, string minor, int credits);

    //Prints Student's Personal Info and Student Info
    void printPersonalInfo();

    //Prints Student Info
    void virtual printStudentInfo();

};




