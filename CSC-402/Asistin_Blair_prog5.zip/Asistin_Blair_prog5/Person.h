//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#pragma once
#include <string>
using namespace std;


class Person {
protected:
    string firstname;
    string lastname;
    string streetaddress;
    string city;
    string state;
    string zipcode;
    string phone;
    int age;

public:

    Person(); //Default Constructor
    Person(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age); //Constructor



    void virtual printPersonalInfo(); //Print Person Personal Info

};



