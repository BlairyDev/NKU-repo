//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#pragma once
#include <string>
#include "Person.h"
#include <iostream>
using namespace std;

class Faculty : virtual public Person{
protected:
    string department;
    string office;
    string email;
    string officePhone;

public:

    //Default Constructor
    Faculty();

    //Constructor for storing Person Constructor and data members of Faculty
    Faculty(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age, string department, string office, string email, string officePhone);

    //Constructor to be used for TeachingAsst class
    Faculty(string department, string office, string email, string officePhone);

    //Prints Faculty's Personal Info and Faculty Info
    void printPersonalInfo();

    //Prints Faculty Info
    void printFacultyInfo();

};



