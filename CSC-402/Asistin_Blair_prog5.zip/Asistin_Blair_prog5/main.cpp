//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

//Description:
//This program implements multiple inheritance and polymorphism. It outputs the information of Student, Faculty, and Teaching Assistant using printPersonalInfo().
//Person class is the base class which gives personal information of the three of the three classes. Student and Faculty are the derived class
//of Person class which also provides their own information, inherit attributes(attributes) and override printPersonalInfo(). TeachingAsst class
//will show multiple inheritance which inherit from Student and Faculty, this would also provide its own information(attributes), inherit attributes
//and override printPersonalInfo().

#include <iostream>
#include <vector>
#include <fstream>
#include "Student.h"
#include "Faculty.h"
#include "TeachingAsst.h"
using namespace std;


int main() {

    //Stores object of Persons
    vector<Person *> people;

    //To be used to store object of Student, Faculty, and Teaching Assistant
    Person *P;
    Student *S;
    Faculty *F;
    TeachingAsst *T;

    string type; //stores Student, Faculty, or Teaching Assistant

    //Personal Info
    string firstname, lastname, streetaddress, city, state, zipcode, phone;
    int age;

    //Student Info
    string classRank, major, minor;
    float gpa;
    int credits;

    //Faculty Info
    string department, office, email, officePhone;

    //Teaching Assistant Info
    int courseLoad;


    string inputPath;

    cout << "Please enter a path to a data file: ";
    cin >> inputPath; //use absolute filepath e.g (/home/blairasistin/CLionProjects/Asistin_Blair_prog5/in1.txt)

    ifstream inf(inputPath);

    //Checks if the file has opened
    if(!inf) {
        cout << "Error opening file " << inputPath << endl;
    }


    while(inf >> type) {

        //Stores the Personal Info of Person
        inf >> firstname >> lastname >> streetaddress >> city >> state >> zipcode >> phone >> age;

        //Checks if the type is a Student or Teaching Assistant
        if(type == "S" || type == "T") {

            //Store Student info to be used for constructor
            inf >> classRank >> gpa >> major >> minor >> credits;

            //This if type is Student
            if(type == "S") {

                //Passed values to constructor
                S = new Student(firstname, lastname, streetaddress, city, state, zipcode, phone, age, classRank, gpa, major, minor, credits);

                P = S;

            }
        }

        //Checks if the type is a Faculty or Teaching Assistant
        if(type == "F" || type == "T") {

            //Stores Faculty Info to be used for constructor
            inf >> department >> office >> email >> officePhone;

            //This checks if type is Faculty
            if(type == "F") {

                //Passed values to constructor
                F = new Faculty(firstname, lastname, streetaddress, city, state, zipcode, phone, age, department, office, email, officePhone);

                P = F;
            }
        }

        //Checks if the type is a Teaching Assistant
        if(type == "T") {
            inf >> courseLoad;

            //Passed values to constructor
            T = new TeachingAsst(firstname, lastname, streetaddress, city, state, zipcode, phone, age, classRank, gpa, major, minor, credits, department, office, email, officePhone, courseLoad);

            P = T;
        }

        people.push_back(P); //Push Object to vector

    }

    //Iterates in the Person vector and call printPersonalInfo to print Information of Student, Faculty, or Teaching Assistant
    for(auto it = people.begin(); it != people.end(); ++it) {

        (*it)->printPersonalInfo();

        cout << endl << endl;
    }


    return 0;

}
