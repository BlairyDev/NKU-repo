//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#include "TeachingAsst.h"

//Default Constructor
TeachingAsst::TeachingAsst() {
    int courseLoad = 0;
}


//Constructor for storing Person Constructor, Student Constructor, and Faculty Constructor
TeachingAsst::TeachingAsst(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age, string classRank, float gpa, string major, string minor, int credits, string department, string office, string email, string officePhone, int courseLoad) :
Person(firstname, lastname, streetaddress, city, state, zipcode, phone, age),
Student(classRank, gpa, major, minor, credits),
Faculty(department, office, email, officePhone), courseLoad(courseLoad){}

//Prints Teaching Assistant's Personal Info, Student Info, and Faculty Info
void TeachingAsst::printPersonalInfo() {

    cout << "T-E-A-C-H-I-N-G A-S-S-I-S-T-A-N-T" << endl;
    cout << "-----------------------------------" << endl;

    Person::printPersonalInfo();

    Student::printStudentInfo();

    Faculty::printFacultyInfo();


    cout << "TEACHING ASSISTANT INFO" << endl;
    cout << "Course Load :  " << courseLoad << endl;

}




