//Name: Blair Asistin
//Course: CSC 402 Advanced Programming Methods

#include "Faculty.h"

//Default Constructor
Faculty::Faculty() {
    department = "NONE";
    office = "NONE";
    email = "NONE";
    officePhone = "NONE";
}

//Constructor for storing Person Constructor and data members of Student
Faculty::Faculty(string firstname, string lastname, string streetaddress, string city, string state, string zipcode, string phone, int age, string department, string office, string email, string officePhone) :
Person(firstname, lastname, streetaddress, city, state, zipcode, phone, age), department(department), office(office), email(email), officePhone(officePhone) {}


//Constructor to be used for TeachingAsst class
Faculty::Faculty(string department, string office, string email, string officePhone) {
    this->department = department;
    this->office = office;
    this->email = email;
    this->officePhone = officePhone;
}

//Prints Faculty's Personal Info and Faculty Info
void Faculty::printPersonalInfo() {
    cout << "F-A-C-U-L-T-Y" << endl;
    cout << "-------------" << endl;

    Person::printPersonalInfo(); //Prints Faculty Personal Info in Faculty Class

    printFacultyInfo(); //Prints Faculty Info
};

//Prints Faculty Info
void Faculty::printFacultyInfo() {

    cout << "FACULTY INFO" << endl;
    cout << email << endl;
    cout << department << endl;
    cout << "Office : " << office << "  " << "Office Phone : " << officePhone << endl;

}
